<?php
    /*
    session_start();
    require_once("twitteroauth/twitteroauth/twitteroauth.php"); //Path to twitteroauth library you downloaded in step 3

    $twitteruser = "trump"; //user name you want to reference
    $notweets = 30; //how many tweets you want to retrieve
    $consumerkey = "Plif4G4N4zzAcprqKPPyAH0H3"; //Noted keys from step 2
    $consumersecret = "v3wFQAiVkd7O7GqKCu1ypmUYauff3ktDjWRjVKNMfdRXEcqTL2"; //Noted keys from step 2
    $accesstoken = "719738403374395396-bGQyW89e7ryMOsqkRCzVIT7WUEBf6fI"; //Noted keys from step 2
    $accesstokensecret = "rbm7DhlCotC8uBxmPbpyDH846qf1uK9IWKNSclp5K9242"; //Noted keys from step 2

    function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) {
        $connection = new TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_token_secret);
        return $connection;
    }

    $connection = getConnectionWithAccessToken($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);

    $tweets = $connection->get("https://stream.twitter.com/1.1/statuses/filter.json?track=twitter");

    var_dump ($tweets);
    echo json_encode($tweets);
    echo $tweets; //testing remove for production   
    */
    
        
    // new content
    include 'lib/EpiCurl.php';
    include 'lib/EpiOAuth.php';
    include 'lib/EpiTwitter.php';
    include 'lib/secret.php';
    
    // create a Twitter obj
    try {
        $twitterObj = new EpiTwitter($consumer_key, $consumer_secret, $access_token, $access_secret);
        $status = $twitterObj->get('/statuses/firehose.json');
        var_dump($status);
        echo '<br>';
        var_dump($status->responseText);
    } catch (EpiTwitterException $e) {
        var_dump($e);
    }
    
    /*
	if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
		$uri = 'https://';
	} else {
		$uri = 'http://';
	}
	$uri .= $_SERVER['HTTP_HOST'];
	// header('Location: '.$uri.'/dashboard/');
    header('Location: '.$uri.'/twitter-async-master/simpleTest.php');
	exit;
    */
?>
<!--Something is wrong with the XAMPP installation :-(-->
