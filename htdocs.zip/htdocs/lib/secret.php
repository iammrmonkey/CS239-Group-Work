<?php
$consumer_key = 'Plif4G4N4zzAcprqKPPyAH0H3';
$consumer_secret = 'v3wFQAiVkd7O7GqKCu1ypmUYauff3ktDjWRjVKNMfdRXEcqTL2';
$access_token = '719738403374395396-bGQyW89e7ryMOsqkRCzVIT7WUEBf6fI';
$access_secret = 'rbm7DhlCotC8uBxmPbpyDH846qf1uK9IWKNSclp5K9242';
?>